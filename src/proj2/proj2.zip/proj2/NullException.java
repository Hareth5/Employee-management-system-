package proj2;

public class
NullException extends Exception {
    public NullException(String message) {
        super(message);
    }
}

